module OpenStack
  module Compute
      class Volume
      end
   end
end